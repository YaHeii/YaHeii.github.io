---
title: Hello World
cover: https://ae01.alicdn.com/kf/H355adba4500642949f3d43d001b83ac3b.jpg
tags: hexo
date: 2021-01-01 00:00:00
updated: 2021-01-01 00:00:00
---
欢迎来到 [Tianli's blog](tianli-blog.club)! 这是一个基于hexo搭建的博客。
## Quick Start

### Create a new post

``` bash
$ hexo new "My New Post"
```

More info: [Writing](https://hexo.io/docs/writing.html)

### Run server

``` bash
$ hexo server
```

More info: [Server](https://hexo.io/docs/server.html)

### Generate static files

``` bash
$ hexo generate
```

More info: [Generating](https://hexo.io/docs/generating.html)

### Deploy to remote sites

``` bash
$ hexo deploy
```

More info: [Deployment](https://hexo.io/docs/one-command-deployment.html)

主题：butterfly
