---
title: 限量免费赠送office365e5账号
date: 2021-02-07 14:50:12
updated: 2021-02-07 14:50:12
tags: office
cover: https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg30.360buyimg.com%2FpopWareDetail%2Fjfs%2Ft1792%2F287%2F132746070%2F145408%2F33a24527%2F55cd50b6N8a740081.jpg&refer=http%3A%2F%2Fimg30.360buyimg.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1615272830&t=58420fc9bf3e92c3e679e0f642095d38
---

**限时免费赠送office365 e5 2T账号了，限量10个**

需要的朋友在评论区留下你需要的账号和邮箱即可，届时密码会发送到你的邮箱

账号有问题可以点击此页面右下角**SMS**联系我
Test![](https://cdn.jsdelivr.net/npm/chenyfan-oss@1.1.8/5896ec2cb7f39.gif)