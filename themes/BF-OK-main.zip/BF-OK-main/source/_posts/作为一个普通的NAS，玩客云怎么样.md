---
title: 作为一个普通的NAS，玩客云怎么样
date: 2020-03-01 16:10:44
updated: 2020-03-01 16:10:44
tags: 
 - NAS
 - 体验
cover: https://tuchuang-1258604854.cos.ap-chengdu.myqcloud.com/coolapk/NAS/1.jpg
---

- [ ] 先不聊这个，大家先看官方宣传图<img src="https://tuchuang-1258604854.cos.ap-chengdu.myqcloud.com/coolapk/NAS/coolapk_emotion_64_shounuehuaji.png" alt="受虐滑稽" style="zoom:33%;" />

![img](https://tuchuang-1258604854.cos.ap-chengdu.myqcloud.com/coolapk/NAS/2.jpg)

事情不简单

前几天和[@Strit](https://www.coolapk.com/u/Strit) 看见了一个老哥的评测<img src="https://tuchuang-1258604854.cos.ap-chengdu.myqcloud.com/coolapk/NAS/coolapk_emotion_64_shounuehuaji.png" alt="受虐滑稽" style="zoom:25%;" />原文链接：[查看链接](https://www.coolapk.com/feed/16832235?shareKey=YWFkYTczMGFkODIzNWU1YjIyNzE~&shareUid=1382033&shareFrom=com.coolapk.market_10.0.1)
我俩都觉得这玩意儿做一个轻NAS很香，于是Strit.就跟我一起商量都整一个，我当时想着我有天翼云的永久会员何必整那玩意儿。所以他就整了一个<img src="https://tuchuang-1258604854.cos.ap-chengdu.myqcloud.com/coolapk/NAS/coolapk_emotion_63_liuhanhuaji.png" alt="流汗滑稽" style="zoom:25%;" />没过几天，我电脑突然无法开机，后面检测发现机械硬盘有点坏道，整好之后我就买了一个硬盘盒，把这个硬盘当移动硬盘用。

![img](https://tuchuang-1258604854.cos.ap-chengdu.myqcloud.com/coolapk/NAS/3.jpg)

别问我为什么买这么贵的，也许这就叫富有吧[喵喵口罩]

后面，我按耐不住自己，又听说这货相当于永久迅雷会员，就买了<img src="https://tuchuang-1258604854.cos.ap-chengdu.myqcloud.com/coolapk/NAS/coolapk_emotion_64_shounuehuaji.png" alt="受虐滑稽" style="zoom:25%;" />

接下来进入正题，在2020年，玩客云还能干什么：
首先，它有一个迅雷的称号，下载种子肯定少不了

![img](https://tuchuang-1258604854.cos.ap-chengdu.myqcloud.com/coolapk/NAS/4.jpg)

注意云添加

![img](https://tuchuang-1258604854.cos.ap-chengdu.myqcloud.com/coolapk/NAS/5.jpg)

发现精彩不是我的资源，广告，避免一部分人说我开车

（<img src="https://tuchuang-1258604854.cos.ap-chengdu.myqcloud.com/coolapk/NAS/coolapk_emotion_63_liuhanhuaji.png" alt="流汗滑稽" style="zoom:25%;" />什么？你想下那种片？没门。迅雷敏感资源识别。但是苍老师是不是白名单我就不知道了）
我家是百兆网，上图网速能够跑满百分之七八十左右。
PS:这个云添加也可以下载其它文件，自带百度，谷歌。不过，手机端云添加只能下载种子，而电脑端玩客云太鸡肋，我下载的文件都打不开，只能用Samba1.0协议

至于挖矿!大家都懂，每天几毛钱，电费都不够，而且我这是退出协议的，不想再进去。听说几年前炒到几千，许多老哥估计都哭晕了!

软件特点的话还有DLNA，DLNA<img src="https://tuchuang-1258604854.cos.ap-chengdu.myqcloud.com/coolapk/NAS/coolapk_emotion_105_tnaikezui.png" alt="t耐克嘴" style="zoom:25%;" />不知道是不是我的问题，除了玩客云自家软件其他的APP都连不上。

接下来说下远场访问速度

![img](https://tuchuang-1258604854.cos.ap-chengdu.myqcloud.com/coolapk/NAS/6.jpg)

如图

（我家上传带宽20M，据官网介绍，远场访问最快速度4M/S）1.7M/S，普通办公传传文件够用了。当然肯定不能当做专业NAS用<img src="https://tuchuang-1258604854.cos.ap-chengdu.myqcloud.com/coolapk/NAS/coolapk_emotion_63_liuhanhuaji.png" alt="流汗滑稽" style="zoom:25%;" />。毕竟大多数办公都需要大文件。1.7M/S肯定会疯。

最后，来谈谈硬件：
USB接口X2，两个USB2.0接口<img src="https://tuchuang-1258604854.cos.ap-chengdu.myqcloud.com/coolapk/NAS/coolapk_emotion_63_liuhanhuaji.png" alt="流汗滑稽" style="zoom:25%;" />速度堪忧而且我还是机械硬盘。
这估计是很多人想买却放弃想法

HDMI×1，要是你愿意的话还能当电视盒子用，网络上有大佬刷机成安卓系统用的教程。不过美中不足的是没有音频输出，普通电脑显示器都不带音响的吧

SD卡接口×1，可以传传摄像机上的照片什么的。
千兆网线接口×1，网速比文件传输速度快很多系列

电源。。

最后：我看见许多酷友说硬盘不会自动休眠，需要有Linux禁止文件权限，不过我为了方便就直接用的NTFS文件系统，然后禁止了所有权限，.onething_data改为只读，测试时，三分钟硬盘没有文件传输就自动休眠了。完全不用担心。（别问为什么这么快，问就是硬盘盒主控芯片）

这篇图文写的时候我头有点痛

所以有点杂乱无章，请见谅，以上仅仅代表个人观点 [#NAS#](https://www.coolapk.com/t/NAS?type=12)  

![img](https://tuchuang-1258604854.cos.ap-chengdu.myqcloud.com/coolapk/NAS/7.jpg)

我兄弟[@Strit](https://www.coolapk.com/u/Strit) 的友链

[查看链接](https://www.coolapk.com/feed/16812553?shareKey=YzAzZDhlZTZhZmZhNWU1YjIyNzE~&shareUid=1382033&shareFrom=com.coolapk.market_10.0.1)![](https://cdn.jsdelivr.net/npm/chenyfan-oss@1.1.8/TlAGjm6IvJSMVpq.jpg)