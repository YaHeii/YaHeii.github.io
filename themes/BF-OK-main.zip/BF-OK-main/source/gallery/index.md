---
title: Gallery
date: 2021-02-15 19:48:24
top_img: transparent
comments: false
---

<div class="gallery-group-main">
{% galleryGroup '动漫壁纸' '很漂亮的二刺螈壁纸啦' '/gallery/wallpaper.html' https://tuchuang-1258604854.cos.ap-chengdu.myqcloud.com/web/123%20%2826%29.png %}
{% galleryGroup '2233专区' '收藏的2233高清壁纸' '/gallery/2233.html' https://tuchuang-1258604854.cos.ap-chengdu.myqcloud.com/web/bwt/1613378591933.jpg %}
</div>

***以后api的更新会同步至相册***

### 以上的图片均已加入随机壁纸api

{% btn 'https://img.api.tianli0.top',随机壁纸api链接,far fa-hand-point-right,block center larger %}top_img: transparent

