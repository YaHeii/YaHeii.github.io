---
title: 友情链接
type: "link"
comments: true
top_img: transparent
---

{% issues sites | api=https://gitee.com/api/v5/repos/Tianli/friend-chain/issues?sort=updated&state=open&page=1&per_page=100&labels=active %}

------


{% issues sites | api=https://gitee.com/api/v5/repos/Tianli/friend-chain/issues?sort=updated&state=open&page=1&per_page=100&labels=active %}


# 添加友链示例：

**昵称：**
**网站链接：**
**头像地址：**
**简要概述：**

```yaml
- name: Tianli
  link: https://tianli-blog.club
  avatar: https://img1.tianli0.top/logo.png
  descr: 惟其不可能，所以才相信。
```



### 注意：您申请友链即代表您同意本站抓取您的网站文章

### 您可以在[友链: 友链自动添加 (gitee.com)](https://gitee.com/Tianli0/friend-chain)提交issue自助添加或者在评论区进行留言

