console.log('此博客项目来自BF-OK(https://github.com/TIANLI0/BF-OK)');
console.log(`
  ===================================================================
                                                                     
      #####  #    # ##### ##### ###### #####  ###### #      #   #    
      #    # #    #   #     #   #      #    # #      #       # #     
      #####  #    #   #     #   #####  #    # #####  #        #     
      #    # #    #   #     #   #      #####  #      #        #      
      #    # #    #   #     #   #      #   #  #      #        #    
      #####   ####    #     #   ###### #    # #      ######   #  

                    4.0.0 BF-OK 1.0.0 By Tianli                       
  ===================================================================
`);
console.log("%c    ","background: url(https://img1.tianli0.top/phlogo.png) no-repeat left center;font-size: 200px;","\n");
console.log("\n %c 隐私政策 %c https://tianli-blog.club/privacy/ \n","color: #ffffff; background: #00a6ff; padding:5px 0;","background: #fadfa3; padding:5px 0;")
console.log("\n %c JSD静态资源CDN %c https://cdn1.tianli0.top/ \n","color: #ffffff; background: #00a6ff; padding:5px 0;","background: #fadfa3; padding:5px 0;")
