---
title: 留言板
aside: false
---

<link rel="stylesheet" href="/css/commentsbar.css"/>

  <div id="computer">
    <div id="maincontent"><br>
      <div id="form-wrap"><img src="https://cdn1.tianli0.top/gh/Akilarlxh/Valine-Admin@v1.0/source/img/before.png" id="beforeimg">
        <div id="envelope">
          <form>
            <div class="formmain">
              <img class="headerimg" src="https://ae01.alicdn.com/kf/U5bb04af32be544c4b41206d9a42fcacfd.jpg"/>
              <div style="padding: 5px 20px;">
                <center>
                  <h3 calss="title3">来自Tianli的留言:</h3>
                </center>
                <center class="comments">
                  有什么想问的？<br>
                  有什么想说的？<br>
                  有什么想吐槽的？<br>
                  哪怕是有什么想吃的，都可以告诉我哦~<br>
                </center>
                <div class="bottomcontent">
                <img class="bottomimg" src="https://ae01.alicdn.com/kf/U0968ee80fd5c4f05a02bdda9709b041eE.png"/>
                </div>
                <p class="bottomhr">自动书记人偶竭诚为您服务！！！</p>
              </div>
            </div>
          </form>
        </div><img id="afterimg" src="https://cdn1.tianli0.top/gh/Akilarlxh/Valine-Admin@v1.0/source/img/after.png">
      </div>
    </div>
  </div>
  <div id="mobile">
    <form>
      <div class="formmain"><img class="headerimg" src="https://ae01.alicdn.com/kf/U5bb04af32be544c4b41206d9a42fcacfd.jpg" />
        <div style="padding: 5px 20px;">
          <center>
            <h3 class="title3">来自Tianli的留言:</h3>
          </center>
          <center class="comments">
            有什么想问的？<br>
            有什么想说的？<br>
            有什么想吐槽的？<br>
            哪怕是有什么想吃的，都可以告诉我哦~<br>
          </center>
          <div class="bottomcontent"><img src="https://ae01.alicdn.com/kf/U0968ee80fd5c4f05a02bdda9709b041eE.png" class="bottomhr"></div>
          <p class="bottomhr"">自动书记人偶竭诚为您服务！</p>
        </div>
      </div>
    </form>
  </div>

