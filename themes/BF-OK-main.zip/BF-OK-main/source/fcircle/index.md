---

title: 朋友圈

date: 2021-01-01 00:00:00

comments: false

top_img: false

aside: false

---

<!-- 挂载友链朋友圈的容器 -->
<div id="fcircleContainer">与主机通讯中……</div>
<!-- 加样式和功能代码 -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lmm214/immmmm/themes/hello-friend/static/fcircle-lmm.css">
<script type="text/javascript" src="https://cdn.jsdelivr.net/gh/TIANLI0/immmmm/themes/hello-friend/static/fcircle-lmm.js"></script>





